function loadTable(){
    let users=JSON.parse(localStorage.getItem("users"))||[];
    let tableBody=document.getElementById("tableBody");
    let rows="";
    if(!Array.isArray(users)){
        users=[];
    }
    users.forEach((user,index) => {
        console.log(user.name);
        let finalBalance=localStorage.getItem("balance_"+user.name)||user.balance;
        rows +=`<tr>
        <td>${user.name}</td>
        <td>${user.accountnumber}</td>
        <td>${user.status}</td>
        <td>${finalBalance}</td>
        <td><button onclick="editUser(${index})">Edit</button>
        <button onclick="deleteUser(${index})">Delete</button>
        </td>
        </tr>`;
    });

    tableBody.innerHTML=rows;
   
    document.getElementById("totalCount").innerText=users.length;
    
}

window.onload=loadTable;


function deleteUser(index){
    let users=JSON.parse(localStorage.getItem("users"))||[];
    users.splice(index,1);
    localStorage.setItem("users",JSON.stringify(users));
    loadTable();
}
function editUser(index){
    let users=JSON.parse(localStorage.getItem("users"))||[];
    let newName=prompt("Enter the new name:",users[index].name);
    let newStatus=prompt("Enter the Status",users[index].status);
    if(newName && newStatus){
        users[index].name=newName;
        users[index].status=newStatus;

        localStorage.setItem("users",JSON.stringify(users));
        loadTable();
    }
}
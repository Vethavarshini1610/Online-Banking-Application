function payamount() {
    var sender = document.getElementById("sender").value;
    var receiver = document.getElementById("receiver").value;
    var amount = Number(document.getElementById("amount").value);
    var date = document.getElementById("date").value;

    if (sender === "" || receiver === "" || amount === "" || date === "") {
        alert("Please Enter the Details");
        return;
    }

        let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

        let newTransaction = {
            sender: sender,
            receiver: receiver,
            amount: amount,
            date: new Date().toLocaleDateString()
        };
        transactions.push(newTransaction);
        localStorage.setItem("transactions", JSON.stringify(transactions));

    

    document.querySelector(".overlay").style.display = "block";
    document.querySelector(".popup").style.display = "block"



    fetch("http://localhost:8080/api/transaction", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            sender: sender,
            receiver: receiver,
            amount: amount,
            date: date

        })
    })
        .then(res => res.text())
        .then(data => {
            if (data === "success") {
                alert("Successfully Upload");
            } else {
                alert("Its Error ");
            }
        });
}
function closepopup() {
    document.querySelector(".overlay").style.display = "none";
    document.querySelector(".popup").style.display = "none";
}
let transactions=JSON.parse(localStorage.getItem("transactions"))||[];
let table=document.getElementById("tableclass");
transactions.forEach(function(data,index){
    let row =document.createElement("tr");
   row.innerHTML= `
    <td>${data.sender}</td>
    <td>${data.receiver}</td>
    <td>${data.amount}</td>
    <td>${data.date}</td>
    <td><button onclick="deleteRow(${index})">Delete</button></td>`;
    table.appendChild(row);
});


function deleteRow(index){
    let transactions=JSON.parse(localStorage.getItem("transactions"))||[];
    transactions.splice(index,1);
    localStorage.setItem("transactions",JSON.stringify(transactions));
    location.reload();
}



 
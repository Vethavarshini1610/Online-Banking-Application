package com.example.banking.online.system.model;





import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class FirstUser{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)

    private int id;



    private String role;
    private String username;
    private String password;

    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }


    public String getRole(){
        return role;
    }
    public void setRole(String role){
        this.role=role;
    }
    public String getUsername(){
        return username;
    }
    public void setUsername(String username){
        this.username=username;
    }
    public String getPassword(){
        return password;
    }
    public void setPassword(String password){
        this.password=password;
    }

   
}